#include<iostream>
using namespace std;

class Point
{
public:
	Point() { x = y = 0; }
	Point( int x, int y ) { this->x = x; this->y = y; }
	friend Point operator+(Point &a,int b);
private:
	int x;
	int y;
};

Point operator+(Point &a,int b)
{
	Point result;
	result=a;
	result.x+=b;
	result.y+=b;
	return result;
}

Point operator+(int b,Point &a)
{
	Point result;
	result=a;
	result.x+=b;
	result.y+=b;
	return result;
}

