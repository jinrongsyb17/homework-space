#include<iostream>
using namespace std;

class BaseClass
{
public:
	void fn1();
	void fn2();
};

class DerivedClass:public BaseClass
{
public:
	void fn1();
	void fn2();
};

void BaseClass::fn1(){cout<<"BaseClass fn1()"<<endl;}
void BaseClass::fn2(){cout<<"BaseClass fn2()"<<endl;}
void DerivedClass::fn1(){cout<<"DerivedClass fn1()"<<endl;}
void DerivedClass::fn2(){cout<<"DerivedClass fn2()"<<endl;}

int main()
{
	DerivedClass a;
	BaseClass *baseclass=&a;
	DerivedClass *derivedclass=&a;
	baseclass->fn1();
	baseclass->fn2();
	derivedclass->fn1();
	derivedclass->fn2();
	a.fn1();
	a.fn2();

	system("pause");
}