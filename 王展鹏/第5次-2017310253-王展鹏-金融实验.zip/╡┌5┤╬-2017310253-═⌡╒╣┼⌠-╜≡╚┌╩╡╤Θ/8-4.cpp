#include<iostream>
using namespace std;

class Counter
{
public:
	Counter();
	~Counter(){};
	Counter operator+(const Counter&c2);

};
Counter Counter::operator+(const Counter&c2){}
