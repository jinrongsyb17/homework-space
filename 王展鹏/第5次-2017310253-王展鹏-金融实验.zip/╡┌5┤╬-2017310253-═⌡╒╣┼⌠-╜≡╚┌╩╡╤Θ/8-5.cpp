#include <iostream>
using namespace std;

class Mammal
{
public:
	virtual void speak();

};

class Dog:public Mammal
{
public:
	virtual void speak();
};

void Mammal::speak(){cout<<"Mammal speak"<<endl;}
void Dog::speak(){cout<<"Dog speak"<<endl;}

int main()
{
	Dog dog;
	dog.speak();
	system("pause");

}