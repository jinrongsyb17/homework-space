#include <iostream>
using namespace std;

template<unsigned M,unsigned N>
class Permutation
{
public:
	enum{VALUE=Permutaton<M,N-1>::VALUE*(M-N+1)};
};

template<unsigned M>
class Permutaton<M,1>
{
public:
	enum{VALUE=M};
};

int main()
{
	cout<<Permutation<11,5>::VALUE<<endl;
}