#include<iostream>
using namespace std;

class Shape
{
public:
	Shape(){};
	~Shape(){};

};

class Rectangle:public Shape
{
public:
	Rectangle(){};
	~Rectangle(){};
	float getArea(){return 1;};
};

class Circle : public Shape
{
public:
Circle(){};
~Circle(){};
float getArea(){return 1;};
};

class Square : public Rectangle
{
public:
Square(){};
~Square(){};
};
