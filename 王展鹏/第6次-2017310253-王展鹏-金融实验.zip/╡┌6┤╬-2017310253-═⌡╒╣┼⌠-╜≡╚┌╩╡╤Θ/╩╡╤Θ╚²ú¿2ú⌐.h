#ifndef client_h
#define client_h

class client
{
public:
	client();
	virtual ~client();
};



#endif