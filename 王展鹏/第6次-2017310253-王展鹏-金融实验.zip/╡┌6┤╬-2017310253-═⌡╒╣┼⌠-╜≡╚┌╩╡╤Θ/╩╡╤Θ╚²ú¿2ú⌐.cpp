#include<iostream>
#include"client.h"
using namespace std;

client::client(){}

client::~client(){}